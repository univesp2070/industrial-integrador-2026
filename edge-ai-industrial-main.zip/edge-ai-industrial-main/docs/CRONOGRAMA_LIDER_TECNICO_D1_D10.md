# Cronograma de Execu��o (D1 a D10) � L�der T�cnico

Data de refer�ncia: 2026-04-02
Respons�vel: L�der T�cnico (Firmware + Integra��o)
Base: `docs/PLANO_DE_ACAO.md`, `docs/EDGE_NETWORK_ESP32_ACTION_PLAN.md`, `docs/api/BACKEND_EDGE_INGESTION_REQUIREMENTS.md`

## Objetivo dos 10 dias

Entregar o fluxo validado:
`Simulador/ESP32 -> MQTT (EMQX) -> Backend -> Banco (devices/sensor_data/alerts)`
com contrato est�vel, crit�rios de aceite fechados e time sincronizado.

## Cad�ncia di�ria do l�der (fixa)

1. Daily de 15 min: bloqueios, prioridade do dia, dono por tarefa cr�tica.
2. Check t�cnico de 20 min: contrato MQTT + status de integra��o.
3. Checkpoint fim do dia (10 min): o que foi entregue, risco aberto, plano D+1.

## D1 � Kickoff t�cnico + congelar contrato v1

Objetivo: alinhar todo o time no contrato e no fluxo de integra��o.

Tarefas do l�der:
1. Congelar t�picos MQTT e payload v1 (`sensor/data/{device_id}`, `device/status/{device_id}`).
2. Publicar decis�o de formato de units e timezone (UTC ISO-8601).
3. Apresentar crit�rios de aceite da Fase 1 para todos os devs.
4. Abrir quadro de tarefas por dono (Backend1, Backend2, Front1, Front2, L�der).

Entreg�vel do dia:
1. Contrato v1 aprovado pelo time.
2. Board com tarefas priorizadas e depend�ncias expl�citas.

Gate de sa�da D1:
1. Ningu�m inicia implementa��o sem o contrato v1 assinado pelo time.

## D2 � Simula��o Edge sem hardware

Objetivo: provar envio de dados sem ESP32 f�sico.

Tarefas do l�der:
1. Rodar simulador em `--dry-run` e depois apontando para EMQX local.
2. Demonstrar mensagens em t�picos corretos no broker.
3. Definir frequ�ncia padr�o de publica��o e par�metros de teste.
4. Registrar caso de teste base para repeti��o di�ria.

Entreg�vel do dia:
1. Simulador publicando dados v�lidos no EMQX.
2. Roteiro de teste local documentado.

Gate de sa�da D2:
1. Fluxo `simulador -> broker` reproduz�vel por qualquer dev do time.

## D3 � Base de firmware modular

Objetivo: preparar c�digo do firmware para evolu��o real.

Tarefas do l�der:
1. Estruturar m�dulos `config`, `communication`, `sensors`, `inference` (interfaces/stubs).
2. Ajustar `main.cpp` para fluxo real de setup/loop com chamadas modulares.
3. Definir macro de modo simula��o vs modo hardware real.
4. Fechar checklist de build local do firmware (mesmo sem sensor f�sico).

Entreg�vel do dia:
1. Arquitetura de firmware modular inicial pronta para crescer.

Gate de sa�da D3:
1. Build compila e loop l�gico est� padronizado.

## D4 � Integra��o com Backend (ingest�o MQTT)

Objetivo: iniciar valida��o ponta-a-ponta com backend.

Tarefas do l�der:
1. Alinhar com Backend2 assinatura dos t�picos MQTT.
2. Validar campos obrigat�rios de parsing com Backend1.
3. Executar teste conjunto de ingest�o com payload real do simulador.
4. Registrar diverg�ncias de contrato e corrigir no mesmo dia.

Entreg�vel do dia:
1. Backend consumindo mensagens sem erro estrutural de payload.

Gate de sa�da D4:
1. Mensagens de `sensor/data/+` e `device/status/+` aceitas pelo backend.

## D5 � Persist�ncia no banco + revis�o de mapeamento

Objetivo: garantir dados chegando no schema atual.

Tarefas do l�der:
1. Validar atualiza��o em `devices` (`status`, `last_seen_at`, `firmware_version`).
2. Validar inser��o em `sensor_data` (1 linha por m�trica).
3. Revisar com backend uso de `metadata` JSONB para contexto completo.
4. Confirmar consultas SQL de valida��o operacional.

Entreg�vel do dia:
1. Primeira carga de dados persistida em banco a partir do simulador.

Gate de sa�da D5:
1. `SELECT` de valida��o retorna dados consistentes para pelo menos 1 dispositivo.

## D6 � Regra de alerta (anomaly_score)

Objetivo: fechar ciclo com gera��o de alertas.

Tarefas do l�der:
1. Definir threshold inicial com backend (ex.: `0.8`).
2. Ajustar simulador para produzir eventos an�malos de forma controlada.
3. Testar cria��o de `alerts` com severidade e mensagem padronizada.
4. Definir regra simples de deduplica��o para evitar spam.

Entreg�vel do dia:
1. Alertas autom�ticos gerados por evento an�malo.

Gate de sa�da D6:
1. Pelo menos 1 alerta criado e audit�vel por payload de origem.

## D7 � Resili�ncia de rede

Objetivo: validar comportamento em falha e reconex�o.

Tarefas do l�der:
1. Testar rein�cio do broker durante publica��o.
2. Testar reconex�o e retomada de envio sem travamento.
3. Validar comportamento para payload malformado.
4. Revisar timeout/retry/backoff junto ao backend.

Entreg�vel do dia:
1. Matriz de falhas com comportamento esperado vs observado.

Gate de sa�da D7:
1. Recupera��o ap�s falha de broker comprovada.

## D8 � Valida��o com frontend (consumo de dados reais)

Objetivo: garantir que dados edge chegam at� camada web.

Tarefas do l�der:
1. Sincronizar formato de resposta com Front2.
2. Validar `GET /api/devices`, `/api/sensors/latest/{deviceId}`, `/api/alerts`.
3. Garantir que frontend exibe dado real e n�o mock para 1 fluxo principal.
4. Revisar campos necess�rios para gr�ficos e status de device.

Entreg�vel do dia:
1. Frontend consumindo dados reais de pelo menos 1 dispositivo simulado.

Gate de sa�da D8:
1. Fluxo vis�vel ponta-a-ponta em tela para demo interna.

## D9 � Teste de estabilidade (soak test)

Objetivo: testar estabilidade cont�nua antes do fechamento.

Tarefas do l�der:
1. Executar carga cont�nua por 1 hora com simulador.
2. Monitorar perda de mensagem, reconex�es e lat�ncia percebida.
3. Validar crescimento esperado em `sensor_data` e `alerts`.
4. Consolidar bugs finais e definir corre��es m�nimas de release.

Entreg�vel do dia:
1. Relat�rio curto de estabilidade (1h) com evid�ncias.

Gate de sa�da D9:
1. Sem falha cr�tica impeditiva no fluxo principal.

## D10 � Fechamento t�cnico da sprint

Objetivo: concluir a evolu��o e preparar pr�xima etapa (hardware real).

Tarefas do l�der:
1. Fechar checklist de aceite das Fases 1 e 2 do plano geral.
2. Consolidar handoff t�cnico para backend/frontend com pontos pendentes.
3. Definir backlog da pr�xima sprint (OTA, TFLite real, sensor f�sico).
4. Fazer demo de fluxo completo para o time.

Entreg�vel do dia:
1. Sprint encerrada com evid�ncia de fluxo ponta-a-ponta funcional.
2. Pr�xima sprint planejada com prioridades e riscos.

Gate de sa�da D10:
1. Decis�o formal: pronto para iniciar integra��o com hardware real.

## Quadro de depend�ncias cr�ticas

1. Se backend ingest n�o estiver pronto at� D4, manter trilha de simula��o + valida��o no broker e antecipar resili�ncia (D7).
2. Se endpoints REST atrasarem, validar por SQL e manter frontend em modo h�brido tempor�rio.
3. Se regra de alerta oscilar, congelar threshold em configura��o externa e seguir com valor conservador.

## Riscos e mitiga��o (foco do l�der)

1. Risco: time come�ar com payload diferente.
Mitiga��o: contrato v1 �nico e revis�o di�ria.

2. Risco: backend persistir errado o `sensor_data`.
Mitiga��o: teste com payload conhecido + query de verifica��o por m�trica.

3. Risco: atraso por falta de hardware.
Mitiga��o: simulador como caminho oficial de desenvolvimento at� chegada do sensor.
